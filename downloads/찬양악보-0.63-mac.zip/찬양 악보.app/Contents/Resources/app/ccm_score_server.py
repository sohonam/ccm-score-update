#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""찬양 악보 편집기 — 맥 로컬 앱 (인식 엔진 연결 서버)

파이썬 표준 라이브러리만 사용합니다. 이 폴더의 index.html 을 http://localhost:8765 로 열고,
편집기가 고른 인식 엔진(Gemini / GPT / Claude API, LM Studio, Codex CLI, Gemini CLI, Audiveris)을 대신 호출합니다.
API 키는 ~/.ccm-score/config.json 에만 저장됩니다. 이 컴퓨터(127.0.0.1)에서만 접속할 수 있습니다.
"""
import base64, glob, http.server, platform, json, os, shutil, socketserver, subprocess, sys, tempfile, threading, time, urllib.request, webbrowser

PORT = int(os.environ.get("CCM_PORT", "8765"))
ROOT = os.path.dirname(os.path.abspath(__file__))          # 프로그램 파일(index.html 등)이 있는 곳
# 사용자 자료(악보·기록·악기 소리)를 두는 곳. 배포판 앱은 ~/Library/Application Support/CCMScore 를 넘겨 줌
# (넘겨 주지 않으면 예전처럼 프로그램 폴더 안 — 개발용 ~/dev/ccm-score)
DATA = os.path.expanduser(os.environ.get("CCM_DATA") or ROOT)
os.makedirs(DATA, exist_ok=True)


def app_info():
    """이 프로그램의 판 정보 (VERSION.json) + 어디서 실행 중인지 (설치판 / 패치)"""
    info = {"build": 0, "version": "dev", "feed": ""}
    try:
        with open(os.path.join(ROOT, "VERSION.json"), encoding="utf-8") as f:
            info.update(json.load(f))
    except Exception:
        pass
    info["source"] = os.environ.get("CCM_APP_SOURCE", "dev")          # bundled | patched | dev
    info["bundled_build"] = int(os.environ.get("CCM_BUNDLED_BUILD", "0") or 0)
    info["data"] = DATA
    return info
CFG_DIR = os.path.expanduser(os.environ.get("CCM_CFG_DIR", "~/.ccm-score"))
CFG_PATH = os.path.join(CFG_DIR, "config.json")
STATIC = {"/": "index.html", "/index.html": "index.html", "/pptxgen.bundle.js": "pptxgen.bundle.js"}
DEFAULTS = {
    "gemini_model": "gemini-3.8-flash",
    "openai_model": "gpt-5.5",
    "anthropic_model": "claude-opus-5-5",
    "lmstudio_url": "http://localhost:1234",
    "lmstudio_model": "",
    "codex_model": "",
    "geminicli_model": "",
    "agy_model": "",
    "audiveris_path": "",
}
# 시험용으로 API 주소를 바꿀 수 있게 (보통은 그대로)
BASE = {
    "gemini": os.environ.get("CCM_GEMINI_BASE", "https://generativelanguage.googleapis.com"),
    "openai": os.environ.get("CCM_OPENAI_BASE", "https://api.openai.com"),
    "anthropic": os.environ.get("CCM_ANTHROPIC_BASE", "https://api.anthropic.com"),
}
EXTRA_PATHS = ["/opt/homebrew/bin", "/usr/local/bin", os.path.expanduser("~/.local/bin"), os.path.expanduser("~/.npm-global/bin"),
               os.path.expanduser("~/.bun/bin"), os.path.expanduser("~/.volta/bin")]
os.environ["PATH"] = os.environ.get("PATH", "") + ":" + ":".join(p for p in EXTRA_PATHS if os.path.isdir(p))
for nvm in glob.glob(os.path.expanduser("~/.nvm/versions/node/*/bin")):
    os.environ["PATH"] += ":" + nvm

# 이 앱이 직접 설치하는 도구(Gemini CLI용 node, homr)는 DATA/tools 아래 → PATH 앞에
TOOLS = os.path.join(DATA, "tools")
for _p in (os.path.join(TOOLS, "node", "bin"), os.path.join(TOOLS, "npm", "node_modules", ".bin"), os.path.join(TOOLS, "homr", "bin")):
    os.environ["PATH"] = _p + ":" + os.environ.get("PATH", "")

LOCK = threading.Lock()


def load_cfg():
    cfg = dict(DEFAULTS)
    try:
        with open(CFG_PATH, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return cfg


def save_cfg(cfg):
    os.makedirs(CFG_DIR, exist_ok=True)
    tmp = CFG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, 0o600)
    os.replace(tmp, CFG_PATH)


class EngineError(Exception):
    pass


def http_json(url, body=None, headers=None, timeout=300):
    """curl 로 호출 (맥 기본 인증서 사용 → 파이썬 인증서 문제 없음)"""
    headers = headers or []
    with tempfile.TemporaryDirectory() as td:
        cmd = ["curl", "-sS", "--max-time", str(timeout), "-w", "\n%{http_code}"]
        for h in headers:
            cmd += ["-H", h]
        if body is not None:
            bf = os.path.join(td, "body.json")
            with open(bf, "w", encoding="utf-8") as f:
                json.dump(body, f, ensure_ascii=False)
            cmd += ["-X", "POST", "-H", "Content-Type: application/json", "--data-binary", "@" + bf]
        cmd.append(url)
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 15)
    if r.returncode != 0:
        raise EngineError("연결 실패: " + (r.stderr.strip()[:200] or "curl 오류"))
    out, _, code = r.stdout.rpartition("\n")
    try:
        data = json.loads(out) if out.strip() else {}
    except Exception:
        raise EngineError(f"응답을 읽지 못했습니다 (HTTP {code})")
    if not code.startswith("2"):
        msg = ""
        if isinstance(data, dict):
            e = data.get("error")
            msg = (e.get("message") if isinstance(e, dict) else e) or data.get("message") or ""
        raise EngineError(f"HTTP {code}: {str(msg)[:300]}")
    return data


def need_key(cfg, name, label):
    k = (cfg.get(name) or "").strip()
    if not k:
        raise EngineError(f"{label} API 키가 없습니다 (엔진 설정에서 입력)")
    return k


# ---------------- 엔진들 ----------------
# 무료 키로 쓸 수 있는 Flash 계열 — 고른 모델이 붐비면(503) 차례로 바꿔 시도
GEMINI_FALLBACK = ["gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"]
BUSY = ("503", "500", "502", "504", "high demand", "overloaded", "unavailable", "try again later", "deadline")


def run_gemini(cfg, prompt, images, tier):
    """붐빔(503)·일시 오류는 잠깐 쉬었다 다시, 그래도 안 되면 다른 무료 모델로. 분당 한도(429)는 기다렸다 다시."""
    key = need_key(cfg, "gemini_key", "Gemini")
    first = cfg.get("gemini_model") or DEFAULTS["gemini_model"]
    models = [first] + [m for m in GEMINI_FALLBACK if m != first]
    parts = [{"text": prompt}] + [{"inline_data": {"mime_type": "image/jpeg", "data": b}} for b in images]
    body = {"contents": [{"role": "user", "parts": parts}], "generationConfig": {"responseMimeType": "application/json"}}
    last = None
    for mi, model in enumerate(models[:3]):
        for attempt in range(2):
            try:
                d = http_json(f"{BASE['gemini']}/v1beta/models/{model}:generateContent", body, ["x-goog-api-key: " + key], 600)
                try:
                    return "".join(p.get("text", "") for p in d["candidates"][0]["content"]["parts"])
                except Exception:
                    raise EngineError("Gemini 응답에 내용이 없습니다")
            except EngineError as e:
                last = e
                m = str(e).lower()
                if "429" in m or "quota" in m or "rate" in m:
                    if "per day" in m or "daily" in m or "perday" in m:
                        raise EngineError("오늘 무료 사용 횟수를 다 썼습니다 — 내일 다시 하거나 다른 엔진을 쓰세요")
                    time.sleep(12 + attempt * 10)          # 분당 한도: 잠깐 기다렸다 다시
                    continue
                if "404" in m or "not found" in m or "not supported" in m:
                    break                                 # 이 모델은 없음 → 다음 모델
                if any(k in m for k in BUSY):
                    time.sleep(2 + attempt * 4)            # 붐빔: 잠깐 쉬었다 다시
                    continue
                raise
    raise EngineError("Gemini가 지금 붐빕니다 (여러 번 다시 해 봄). 잠시 뒤 실패한 줄의 ‘다시’를 누르세요 — " + str(last)[:120])


def openai_like(url, key, model, prompt, images, json_mode=True, timeout=600):
    content = [{"type": "text", "text": prompt}] + [
        {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + b, "detail": "high"}} for b in images]
    body = {"model": model, "messages": [{"role": "user", "content": content}]}
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    hdr = ["Authorization: Bearer " + key] if key else []
    d = http_json(url, body, hdr, timeout)
    try:
        c = d["choices"][0]["message"]["content"]
        return c if isinstance(c, str) else "".join(x.get("text", "") for x in c)
    except Exception:
        raise EngineError("응답에 내용이 없습니다")


def run_openai(cfg, prompt, images, tier):
    key = need_key(cfg, "openai_key", "OpenAI")
    return openai_like(f"{BASE['openai']}/v1/chat/completions", key, cfg.get("openai_model") or DEFAULTS["openai_model"], prompt, images)


def run_anthropic(cfg, prompt, images, tier):
    key = need_key(cfg, "anthropic_key", "Anthropic")
    content = [{"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": b}} for b in images]
    content.append({"type": "text", "text": prompt})
    body = {"model": cfg.get("anthropic_model") or DEFAULTS["anthropic_model"], "max_tokens": 16000,
            "messages": [{"role": "user", "content": content}]}
    d = http_json(f"{BASE['anthropic']}/v1/messages", body, ["x-api-key: " + key, "anthropic-version: 2023-06-01"], 600)
    try:
        return "".join(b.get("text", "") for b in d["content"] if b.get("type") == "text")
    except Exception:
        raise EngineError("Claude 응답에 내용이 없습니다")


def lmstudio_models(cfg):
    url = (cfg.get("lmstudio_url") or DEFAULTS["lmstudio_url"]).rstrip("/")
    try:
        with urllib.request.urlopen(url + "/v1/models", timeout=1.5) as r:
            d = json.load(r)
        return [m.get("id") for m in d.get("data", []) if m.get("id")]
    except Exception:
        return None


def run_lmstudio(cfg, prompt, images, tier):
    url = (cfg.get("lmstudio_url") or DEFAULTS["lmstudio_url"]).rstrip("/")
    model = cfg.get("lmstudio_model") or ""
    if not model:
        ms = lmstudio_models(cfg)
        if not ms:
            raise EngineError("LM Studio 서버가 꺼져 있거나 불러온 모델이 없습니다")
        model = ms[0]
    return openai_like(url + "/v1/chat/completions", "", model, prompt, images, json_mode=False, timeout=900)


def write_images(td, images):
    paths = []
    for i, b in enumerate(images):
        p = os.path.join(td, f"strip{i + 1}.jpg")
        with open(p, "wb") as f:
            f.write(base64.b64decode(b))
        paths.append(p)
    return paths


def run_codex_cli(cfg, prompt, images, tier):
    exe = shutil.which("codex")
    if not exe:
        raise EngineError("codex 명령을 찾지 못했습니다")
    with tempfile.TemporaryDirectory() as td:
        paths = write_images(td, images)
        out = os.path.join(td, "answer.txt")
        full = prompt + "\n\nThe images are attached. Do not run any commands; just answer with the JSON."
        base = [exe, "exec", "--skip-git-repo-check", "--sandbox", "read-only", "--color", "never", "-o", out]
        if cfg.get("codex_model"):
            base += ["-m", cfg["codex_model"]]
        base += ["--image", ",".join(paths)]
        # 1) 지시문을 '--' 뒤에 (사진 옵션이 지시문을 삼키지 않게)  2) 안 되면 표준입력으로
        tries = [(base + ["--", full], None), (base + ["-"], full)]
        last = ""
        for cmd, stdin_text in tries:
            if os.path.exists(out):
                os.remove(out)
            r = subprocess.run(cmd, cwd=td, capture_output=True, text=True, timeout=900,
                               input=stdin_text, stdin=None if stdin_text is not None else subprocess.DEVNULL)
            txt = open(out, encoding="utf-8").read() if os.path.exists(out) else ""
            if txt.strip():
                return txt
            last = (r.stderr.strip() or r.stdout.strip())[-300:]
        raise EngineError("Codex 실행 실패: " + (last or "응답 없음"))


def run_gemini_cli(cfg, prompt, images, tier):
    exe = shutil.which("gemini")
    if not exe:
        raise EngineError("gemini 명령을 찾지 못했습니다")
    with tempfile.TemporaryDirectory() as td:
        paths = write_images(td, images)
        refs = " ".join("@" + os.path.basename(p) for p in paths)
        cmd = [exe, "-p", prompt + "\n\nImages (in order): " + refs]
        if cfg.get("geminicli_model"):
            cmd += ["-m", cfg["geminicli_model"]]
        # 임시 폴더에서 돌리므로 ‘믿을 수 있는 폴더’ 확인을 건너뜀 (새 Gemini CLI는 안 하면 바로 멈춤)
        env = dict(os.environ, GEMINI_CLI_TRUST_WORKSPACE="true")
        r = subprocess.run(cmd, cwd=td, capture_output=True, text=True, timeout=900, stdin=subprocess.DEVNULL, env=env)
        if not r.stdout.strip() and "trust" in (r.stderr or "").lower():
            r = subprocess.run(cmd[:1] + ["--skip-trust"] + cmd[1:], cwd=td, capture_output=True, text=True, timeout=900, stdin=subprocess.DEVNULL, env=env)
        if not r.stdout.strip():
            raise EngineError("Gemini CLI 실행 실패: " + (r.stderr.strip()[-300:] or "응답 없음"))
        return r.stdout


def agy_logged_in():
    """Antigravity CLI 로그인은 맥 키체인(서비스 gemini, 계정 antigravity)에 저장됨"""
    try:
        r = subprocess.run(["security", "find-generic-password", "-s", "gemini", "-a", "antigravity"], capture_output=True, timeout=10)
        if r.returncode == 0:
            return True
    except Exception:
        pass
    return bool(os.environ.get("GEMINI_API_KEY")) or os.path.exists(os.path.expanduser("~/.gemini/antigravity-cli/oauth_creds.json"))


def run_agy_cli(cfg, prompt, images, tier):
    """Antigravity CLI(agy) — 구글 개인 계정 무료(주간 한도). Gemini CLI의 후속 (2026-06-18부터 개인 계정은 agy)"""
    exe = shutil.which("agy")
    if not exe:
        raise EngineError("agy 명령을 찾지 못했습니다")
    with tempfile.TemporaryDirectory() as td:
        paths = write_images(td, images)
        refs = " ".join("@" + os.path.basename(p) for p in paths)
        full = prompt + "\n\nImages (in order): " + refs + "\nRead the image files above. Do not run commands or edit files; answer only with the JSON."
        cmd = [exe, "-p", full]
        if cfg.get("agy_model"):
            cmd += ["--model", cfg["agy_model"]]
        env = dict(os.environ, GEMINI_CLI_TRUST_WORKSPACE="true")
        r = subprocess.run(cmd, cwd=td, capture_output=True, text=True, timeout=900, stdin=subprocess.DEVNULL, env=env)
        if not r.stdout.strip():
            raise EngineError("Antigravity 실행 실패: " + (r.stderr.strip()[-300:] or "응답 없음"))
        return r.stdout


def audiveris_exe(cfg):
    cands = [cfg.get("audiveris_path") or "", "/Applications/Audiveris.app/Contents/MacOS/Audiveris",
             os.path.expanduser("~/Applications/Audiveris.app/Contents/MacOS/Audiveris"), shutil.which("audiveris") or "",
             shutil.which("Audiveris") or ""]
    cands += glob.glob("/Applications/Audiveris*.app/Contents/MacOS/Audiveris") + glob.glob(os.path.expanduser("~/Applications/Audiveris*.app/Contents/MacOS/Audiveris"))
    for c in cands:
        if c and os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def run_audiveris(cfg, image_b64):
    exe = audiveris_exe(cfg)
    if not exe:
        raise EngineError("Audiveris가 설치되어 있지 않습니다")
    with tempfile.TemporaryDirectory() as td:
        img = os.path.join(td, "page.png")
        with open(img, "wb") as f:
            f.write(base64.b64decode(image_b64))
        out = os.path.join(td, "out")
        os.makedirs(out)
        cmd = [exe, "-batch", "-export", "-output", out, "--", img]
        with LOCK:  # Audiveris는 한 번에 하나씩
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        found = glob.glob(os.path.join(td, "**", "*.mxl"), recursive=True)
        log = (r.stdout or "") + "\n--- stderr ---\n" + (r.stderr or "")
        try:
            os.makedirs(os.path.join(DATA, "logs"), exist_ok=True)
            with open(os.path.join(DATA, "logs", "audiveris-last.log"), "w", encoding="utf-8") as f:
                f.write(" ".join(cmd) + f"\nreturncode={r.returncode}\nfiles={glob.glob(os.path.join(td, '**', '*'), recursive=True)}\n\n" + log[-20000:])
        except Exception:
            pass
        if not found:
            hint = ""
            for line in log.splitlines():
                l = line.lower()
                if any(k in l for k in ("resolution", "interline", "too low", "no staff", "severe", "error", "exception")):
                    hint = line.strip()[-160:]
                    if "resolution" in l or "interline" in l:
                        break
            raise EngineError("Audiveris가 악보를 읽지 못했습니다" + (": " + hint if hint else f" (종료 코드 {r.returncode})"))
        with open(found[0], "rb") as f:
            return base64.b64encode(f.read()).decode()


# ---------------- Gemini CLI · homr 설치 (v49) ----------------
# 둘 다 무료. 관리자 암호 없이 DATA/tools 아래에만 설치. 진행 상황은 TOOL_ST[이름] = {state, msg, pct}
TOOL_ST = {"geminicli": {"state": "idle", "msg": "", "pct": 0}, "homr": {"state": "idle", "msg": "", "pct": 0}, "agy": {"state": "idle", "msg": "", "pct": 0}}


def install_agy():
    """구글 공식 설치 스크립트 (관리자 암호 없이 홈 폴더에 설치)"""
    n = "agy"
    try:
        _tst(n, "run", "Antigravity CLI 설치하는 중… (1~2분)", 20)
        r = subprocess.run(["/bin/bash", "-c", "curl -fsSL https://antigravity.google/cli/install.sh | bash"], capture_output=True, text=True, timeout=900)
        for d in ("~/.local/bin", "~/.antigravity/bin", "~/bin"):
            d = os.path.expanduser(d)
            if os.path.isdir(d) and d not in os.environ["PATH"]:
                os.environ["PATH"] = d + ":" + os.environ["PATH"]
        if not shutil.which("agy"):
            raise EngineError("설치하지 못했습니다: " + (r.stderr or r.stdout or "").strip()[-300:])
        _tst(n, "done", "설치했습니다 — 이제 구글 계정으로 로그인하세요", 100)
    except Exception as e:
        _tst(n, "err", str(e)[:300])


AGY_WIN = {"id": None}


def agy_login():
    """터미널 창을 열어 agy 를 실행 (로그인 화면). 창 번호를 기억해 두었다가
    편집기에 붙여 넣은 인증 코드를 그 창에 대신 입력해 줌 (agy_code)"""
    exe = shutil.which("agy")
    if not exe:
        raise EngineError("Antigravity CLI가 설치되어 있지 않습니다")
    home = os.path.expanduser("~")
    cmd = f"cd '{home}'; clear; echo '[찬양 악보] 브라우저에서 구글 로그인 → 화면에 나온 인증 코드를 편집기의 칸에 붙여 넣으세요.'; echo; '{exe}'"
    r = subprocess.run(["osascript", "-e", f'tell application "Terminal"\nset t to do script "{cmd}"\nactivate\nreturn id of (first window whose tabs contains t)\nend tell'],
                       capture_output=True, text=True, timeout=30)
    try:
        AGY_WIN["id"] = int((r.stdout or "").strip())
    except Exception:
        AGY_WIN["id"] = None
    return {"ok": True, "window": AGY_WIN["id"]}


# ---- 터미널 창 없이 로그인 (v53) ----
# 보이지 않는 가상 터미널(pty)에서 agy 를 실행 → 처음 묻는 화면(색·표시 방식·폴더 믿기)은 Enter로 넘기고,
# 출력에서 로그인 주소를 찾아 편집기가 브라우저로 열어 줌 → 편집기 칸에 붙인 인증 코드를 그대로 입력.
AGY_PTY = {"pid": None, "fd": None, "url": "", "out": "", "state": "idle", "msg": "", "t0": 0}


def _strip_ansi(t):
    import re as _re
    return _re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07|\x1b[()][0-9A-Za-z]|\r", "", t)


def agy_pty_start():
    import pty, re as _re, fcntl, termios, struct, signal
    exe = shutil.which("agy")
    if not exe:
        raise EngineError("Antigravity CLI가 설치되어 있지 않습니다")
    agy_pty_stop()
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(os.path.expanduser("~"))
        env = dict(os.environ, TERM="xterm-256color", COLUMNS="1000", LINES="60",
                   SSH_CONNECTION="127.0.0.1 1 127.0.0.1 22", SSH_TTY="/dev/ttys000", GEMINI_CLI_TRUST_WORKSPACE="true")
        try:
            os.execve(exe, [exe], env)
        except Exception:
            os._exit(127)
    try:
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", 60, 1000, 0, 0))   # 주소가 줄바꿈되지 않게 아주 넓게
    except Exception:
        pass
    AGY_PTY.update(pid=pid, fd=fd, url="", out="", state="run", msg="로그인 주소를 기다리는 중…", t0=time.time())

    AGY_PTY["last_out"] = time.time()

    def reader():
        while AGY_PTY["fd"] == fd:
            try:
                chunk = os.read(fd, 4096).decode("utf-8", "ignore")
            except OSError:
                break
            if not chunk:
                break
            AGY_PTY["out"] = (AGY_PTY["out"] + _strip_ansi(chunk))[-20000:]
            AGY_PTY["last_out"] = time.time()
            if not AGY_PTY["url"]:
                m = _re.findall(r"https://[^\s'\"<>]+", AGY_PTY["out"])
                m = [u for u in m if any(k in u for k in ("accounts.google", "oauth", "auth", "signin", "login"))]
                if m:
                    AGY_PTY["url"] = m[-1].rstrip(".,)")
                    AGY_PTY["msg"] = "브라우저에서 로그인한 뒤 인증 코드를 붙여 넣으세요"
                    if sys.platform == "darwin":          # 기본 브라우저로 로그인 페이지 열기
                        subprocess.run(["open", AGY_PTY["url"]], capture_output=True, timeout=20)
        if AGY_PTY["state"] == "run":
            ok = agy_logged_in()
            AGY_PTY.update(state="done" if ok else "err", msg="로그인했습니다" if ok else "로그인 화면이 닫혔습니다")
        agy_pty_stop(keep_state=True)

    def pilot():
        """처음 묻는 화면(색·표시 방식·폴더 믿기·로그인 방법)은 출력이 멈추면 Enter(기본값)로 넘김. 로그인되면 끝냄"""
        enters = 0
        while AGY_PTY["fd"] == fd:
            time.sleep(0.4)
            if agy_logged_in():
                AGY_PTY.update(state="done", msg="로그인했습니다")
                agy_pty_stop(keep_state=True)
                break
            quiet = time.time() - AGY_PTY["last_out"] > 0.8
            if not AGY_PTY["url"] and quiet and enters < 10 and _re.search(r"(?i)(theme|colou?r|scheme|alt-screen|inline|trust|continue|enter|sign in|log ?in|google|select|choose)", AGY_PTY["out"][-500:]):
                enters += 1
                AGY_PTY["last_out"] = time.time()
                try:
                    os.write(fd, b"\r")
                except OSError:
                    break

    threading.Thread(target=reader, daemon=True).start()
    threading.Thread(target=pilot, daemon=True).start()
    # 5분 지나면 정리
    tm = threading.Timer(300, lambda: agy_pty_stop(keep_state=True) if AGY_PTY["pid"] == pid else None)
    tm.daemon = True
    tm.start()
    return {"ok": True}


def agy_pty_stop(keep_state=False):
    import signal
    pid, fd = AGY_PTY.get("pid"), AGY_PTY.get("fd")
    AGY_PTY.update(pid=None, fd=None)
    if pid:
        try:
            os.kill(pid, signal.SIGTERM)
            os.waitpid(pid, os.WNOHANG)
        except Exception:
            pass
    if fd:
        try:
            os.close(fd)
        except Exception:
            pass
    if not keep_state:
        AGY_PTY.update(url="", out="", state="idle", msg="")


def agy_pty_status():
    st = {k: AGY_PTY[k] for k in ("url", "state", "msg")}
    st["logged"] = agy_logged_in() if shutil.which("agy") else False
    if st["state"] == "run" and not st["url"] and time.time() - AGY_PTY["t0"] > 25:
        st["msg"] = "로그인 주소를 찾지 못했습니다 — ‘터미널로 로그인’을 써 주세요"
        st["tail"] = AGY_PTY["out"][-400:]
    return st


def agy_code(code):
    """편집기에서 받은 인증 코드를 agy 가 기다리는 터미널 창에 입력 (Enter 포함)"""
    import re as _re
    code = code.strip()
    if not _re.fullmatch(r"[A-Za-z0-9/_.~=+-]{4,400}", code):
        raise EngineError("인증 코드 모양이 아닙니다 — 브라우저에 나온 코드를 그대로 복사해 주세요")
    if AGY_PTY.get("fd"):          # 보이지 않는 로그인 화면이 기다리는 중이면 거기에 바로
        os.write(AGY_PTY["fd"], code.encode() + b"\r")
        AGY_PTY["msg"] = "코드를 넣었습니다 — 확인하는 중…"
        return {"ok": True}
    target = f"window id {AGY_WIN['id']}" if AGY_WIN["id"] else "front window"
    r = subprocess.run(["osascript", "-e", f'tell application "Terminal" to do script "{code}" in (selected tab of {target})'], capture_output=True, text=True, timeout=20)
    if r.returncode != 0:
        raise EngineError("터미널 창에 넣지 못했습니다 — 터미널 창에 직접 붙여 넣고 Enter: " + (r.stderr or "").strip()[-150:])
    return {"ok": True}


def test_gemini_key(key):
    """무료 API 키가 맞는지 짧게 물어봄 (저장 전 확인)"""
    cfg = load_cfg()
    cfg["gemini_key"] = key.strip()
    txt = run_gemini(cfg, 'Reply with exactly this JSON: {"ok": true}', [], None)
    return {"ok": True, "reply": txt[:80], "model": cfg.get("gemini_model") or DEFAULTS["gemini_model"]}
NODE_VER = os.environ.get("CCM_NODE_VER", "v22.12.0")
PY_STANDALONE = "https://github.com/astral-sh/python-build-standalone/releases/download/20241016/cpython-3.12.7%2B20241016-{t}-install_only.tar.gz"


def _tst(name, state, msg, pct=None):
    TOOL_ST[name].update(state=state, msg=msg)
    if pct is not None:
        TOOL_ST[name]["pct"] = pct


def _arch_mac():
    return "arm64" if platform.machine().lower() in ("arm64", "aarch64") else "x64"


def gemini_logged_in():
    h = os.path.expanduser("~/.gemini")
    if os.path.exists(os.path.join(h, "oauth_creds.json")) or os.environ.get("GEMINI_API_KEY"):
        return True
    try:
        st = json.load(open(os.path.join(h, "settings.json"), encoding="utf-8"))
        return "api" in json.dumps(st).lower() and bool(os.environ.get("GEMINI_API_KEY"))
    except Exception:
        return False


def _download(name, url, dst, p0, p1):
    proc = subprocess.Popen(["curl", "-sSfL", "-m", "1200", "-o", dst, url], stderr=subprocess.PIPE, text=True)
    k = 0
    while proc.poll() is None:
        time.sleep(0.5)
        k += 1
        TOOL_ST[name]["pct"] = min(p1, p0 + k)
    if proc.returncode != 0:
        raise EngineError("내려받기 실패: " + (proc.stderr.read().strip()[:200] if proc.stderr else url))


def install_geminicli():
    n = "geminicli"
    try:
        npm = shutil.which("npm")
        if not npm:
            _tst(n, "run", "Node.js(실행 도구)를 받는 중…", 3)
            td = tempfile.mkdtemp(prefix="ccm-node-")
            name = f"node-{NODE_VER}-darwin-{_arch_mac()}"
            tgz = os.path.join(td, name + ".tar.gz")
            _download(n, f"https://nodejs.org/dist/{NODE_VER}/{name}.tar.gz", tgz, 3, 40)
            _tst(n, "run", "Node.js 푸는 중…", 42)
            subprocess.run(["tar", "-xzf", tgz, "-C", td], check=True, timeout=300)
            dst = os.path.join(TOOLS, "node")
            shutil.rmtree(dst, ignore_errors=True)
            os.makedirs(TOOLS, exist_ok=True)
            shutil.move(os.path.join(td, name), dst)
            shutil.rmtree(td, ignore_errors=True)
            npm = os.path.join(dst, "bin", "npm")
        _tst(n, "run", "Gemini CLI 설치하는 중… (1~3분)", 50)
        pre = os.path.join(TOOLS, "npm")
        os.makedirs(pre, exist_ok=True)
        r = subprocess.run([npm, "install", "--prefix", pre, "@google/gemini-cli@latest"], capture_output=True, text=True, timeout=900)
        if r.returncode != 0 or not shutil.which("gemini"):
            raise EngineError("Gemini CLI 설치 실패: " + (r.stderr or r.stdout).strip()[-300:])
        # 처음 실행 때 ‘구글 계정으로 로그인’이 바로 나오게
        h = os.path.expanduser("~/.gemini")
        os.makedirs(h, exist_ok=True)
        sp = os.path.join(h, "settings.json")
        if not os.path.exists(sp):
            with open(sp, "w", encoding="utf-8") as f:
                json.dump({"selectedAuthType": "oauth-personal", "security": {"auth": {"selectedType": "oauth-personal"}}}, f)
        _tst(n, "done", "설치했습니다 — 이제 구글 계정으로 로그인하세요", 100)
    except Exception as e:
        _tst(n, "err", str(e)[:300])


def gemini_login():
    """터미널을 열어 gemini 를 실행 → 사용자가 ‘Login with Google’을 고르면 브라우저에서 로그인"""
    exe = shutil.which("gemini")
    if not exe:
        raise EngineError("Gemini CLI가 설치되어 있지 않습니다")
    path = os.environ.get("PATH", "")
    cmd = f"export PATH='{path}'; clear; echo '구글 계정으로 로그인하세요. 로그인을 마치면 이 창을 닫아도 됩니다.'; echo; '{exe}'"
    subprocess.run(["osascript", "-e", f'tell application "Terminal" to do script "{cmd.replace(chr(34), chr(92) + chr(34))}"', "-e", 'tell application "Terminal" to activate'],
                   capture_output=True, timeout=30)
    return {"ok": True}


def _py311():
    """homr 는 파이썬 3.11 이상: 쓸 수 있는 것을 찾고 없으면 받아 옴"""
    cands = [os.path.join(DATA, "python", "bin", "python3"), sys.executable, "/opt/homebrew/bin/python3.12", "/opt/homebrew/bin/python3.11",
             "/usr/local/bin/python3.12", "/usr/local/bin/python3.11", shutil.which("python3.12") or "", shutil.which("python3.11") or ""]
    for c in cands:
        if c and os.path.exists(c):
            r = subprocess.run([c, "-c", "import sys;print(sys.version_info[:2]>=(3,11))"], capture_output=True, text=True, timeout=30)
            if r.stdout.strip() == "True":
                return c
    _tst("homr", "run", "파이썬 3.12를 받는 중…", 3)
    t = "aarch64-apple-darwin" if _arch_mac() == "arm64" else "x86_64-apple-darwin"
    td = tempfile.mkdtemp(prefix="ccm-py-")
    tgz = os.path.join(td, "py.tgz")
    _download("homr", PY_STANDALONE.format(t=t), tgz, 3, 25)
    subprocess.run(["tar", "-xzf", tgz, "-C", td], check=True, timeout=300)
    dst = os.path.join(DATA, "python")
    shutil.rmtree(dst, ignore_errors=True)
    shutil.move(os.path.join(td, "python"), dst)
    return os.path.join(dst, "bin", "python3")


def homr_exe():
    p = os.path.join(TOOLS, "homr", "bin", "homr")
    return p if os.path.exists(p) else None


def install_homr():
    n = "homr"
    try:
        py = _py311()
        venv = os.path.join(TOOLS, "homr")
        _tst(n, "run", "설치 공간 만드는 중…", 28)
        shutil.rmtree(venv, ignore_errors=True)
        subprocess.run([py, "-m", "venv", venv], check=True, timeout=300)
        pip = os.path.join(venv, "bin", "pip")
        _tst(n, "run", "homr 설치하는 중… (처음 한 번, 몇 분 걸림)", 35)
        r = subprocess.run([pip, "install", "--upgrade", "pip"], capture_output=True, text=True, timeout=600)
        r = subprocess.run([pip, "install", "homr[cpu]"], capture_output=True, text=True, timeout=3600)
        if r.returncode != 0 or not homr_exe():
            raise EngineError("homr 설치 실패: " + (r.stderr or r.stdout).strip()[-300:])
        _tst(n, "done", "설치했습니다 — 처음 인식할 때 모델 파일을 한 번 더 받습니다", 100)
    except Exception as e:
        _tst(n, "err", str(e)[:300])


def run_homr(image_b64):
    exe = homr_exe()
    if not exe:
        raise EngineError("homr가 설치되어 있지 않습니다")
    with tempfile.TemporaryDirectory() as td:
        img = os.path.join(td, "page.png")
        with open(img, "wb") as f:
            f.write(base64.b64decode(image_b64))
        with LOCK:
            r = subprocess.run([exe, img], cwd=td, capture_output=True, text=True, timeout=1800)
        found = glob.glob(os.path.join(td, "*.musicxml")) + glob.glob(os.path.join(td, "*.xml"))
        try:
            os.makedirs(os.path.join(DATA, "logs"), exist_ok=True)
            with open(os.path.join(DATA, "logs", "homr-last.log"), "w", encoding="utf-8") as f:
                f.write(f"returncode={r.returncode}\n{(r.stdout or '')[-8000:]}\n--- stderr ---\n{(r.stderr or '')[-8000:]}")
        except Exception:
            pass
        if not found:
            raise EngineError("homr가 악보를 읽지 못했습니다: " + (r.stderr or r.stdout or "").strip()[-200:])
        return open(found[0], encoding="utf-8").read()


# ---------------- Audiveris 자동 설치 ----------------
GH_API = os.environ.get("CCM_GH_API", "https://api.github.com")
INSTALL = {"state": "idle", "msg": "", "pct": 0}


def _inst(state, msg, pct=None):
    INSTALL["state"], INSTALL["msg"] = state, msg
    if pct is not None:
        INSTALL["pct"] = pct


def attach_dmg(dmg, mnt, td):
    """사용권 동의 창이 있는 .dmg도 열 수 있게: 1) 동의(Y) 자동 입력  2) 안 되면 동의 창 없는 형식으로 변환 후 열기"""
    env = dict(os.environ, PAGER="/bin/cat")
    base = ["hdiutil", "attach", "-nobrowse", "-readonly", "-noautoopen", "-noverify", "-mountpoint", mnt]
    err = ""
    try:
        r = subprocess.run(base + [dmg], input="Y\n", capture_output=True, text=True, timeout=90, env=env)
        if r.returncode == 0 and os.listdir(mnt):
            return
        err = (r.stderr or r.stdout or "").strip()[-200:]
    except subprocess.TimeoutExpired:
        err = "동의 창에서 멈춤"
        subprocess.run(["hdiutil", "detach", mnt, "-force", "-quiet"], capture_output=True, timeout=60)
    _inst("run", "설치 파일 형식을 바꾸는 중…", 90)
    cdr = os.path.join(td, "plain.cdr")
    r = subprocess.run(["hdiutil", "convert", dmg, "-format", "UDTO", "-o", cdr], capture_output=True, text=True, timeout=300, env=env)
    if r.returncode != 0 or not os.path.exists(cdr):
        raise EngineError("설치 파일을 열지 못했습니다 (" + err + " / " + (r.stderr or "").strip()[-150:] + ")")
    r = subprocess.run(base + [cdr], input="Y\n", capture_output=True, text=True, timeout=120, env=env)
    if r.returncode != 0 or not os.listdir(mnt):
        raise EngineError("설치 파일을 열지 못했습니다: " + (r.stderr or "").strip()[-200:])


def install_audiveris():
    """GitHub 최신 릴리스에서 맥 칩에 맞는 .dmg를 받아 ~/Applications 에 설치 (관리자 암호 필요 없음)"""
    td = tempfile.mkdtemp(prefix="ccm-audiveris-")
    mnt = os.path.join(td, "mnt")
    try:
        if sys.platform != "darwin" and not os.environ.get("CCM_FAKE_MAC"):
            raise EngineError("맥에서만 자동 설치할 수 있습니다")
        _inst("run", "최신 버전을 찾는 중…", 2)
        rel = http_json(f"{GH_API}/repos/Audiveris/audiveris/releases/latest", None, ["Accept: application/vnd.github+json", "User-Agent: ccm-score"], 30)
        arch = "arm64" if platform.machine().lower() in ("arm64", "aarch64") else "x86_64"
        assets = [a for a in rel.get("assets", []) if a.get("name", "").lower().endswith(".dmg")]
        pick = [a for a in assets if arch in a["name"].lower()] or [a for a in assets if "mac" in a["name"].lower()]
        if not pick:
            raise EngineError("맥용 설치 파일을 찾지 못했습니다")
        a = pick[0]
        size = int(a.get("size") or 0)
        dmg = os.path.join(td, a["name"])
        _inst("run", f"{rel.get('tag_name', '')} 내려받는 중 ({size // 1048576}MB)…", 5)
        proc = subprocess.Popen(["curl", "-sSL", "--fail", "-o", dmg, a["browser_download_url"]], stderr=subprocess.PIPE, text=True)
        while proc.poll() is None:
            time.sleep(0.5)
            if size and os.path.exists(dmg):
                INSTALL["pct"] = 5 + int(80 * min(1, os.path.getsize(dmg) / size))
        if proc.returncode != 0:
            raise EngineError("내려받기 실패: " + (proc.stderr.read().strip()[:200] if proc.stderr else ""))
        _inst("run", "설치하는 중…", 88)
        os.makedirs(mnt)
        attach_dmg(dmg, mnt, td)
        try:
            apps = glob.glob(os.path.join(mnt, "*.app"))
            if not apps:
                raise EngineError("설치 파일 안에서 앱을 찾지 못했습니다")
            dest_dir = os.path.expanduser("~/Applications")
            os.makedirs(dest_dir, exist_ok=True)
            dest = os.path.join(dest_dir, os.path.basename(apps[0]))
            if os.path.exists(dest):
                shutil.rmtree(dest)
            subprocess.run(["cp", "-R", apps[0], dest], check=True, timeout=300)
        finally:
            subprocess.run(["hdiutil", "detach", mnt, "-quiet"], capture_output=True, timeout=60)
        subprocess.run(["xattr", "-dr", "com.apple.quarantine", dest], capture_output=True)
        cfg = load_cfg()
        exe = os.path.join(dest, "Contents", "MacOS", "Audiveris")
        if os.path.exists(exe):
            cfg["audiveris_path"] = exe
            save_cfg(cfg)
        _inst("done", f"설치 완료: {dest}", 100)
    except EngineError as e:
        _inst("error", str(e))
    except subprocess.TimeoutExpired as e:
        _inst("error", "설치 실패: 시간 초과 (" + " ".join(map(str, e.cmd[:2])) + ")")
    except Exception as e:
        _inst("error", "설치 실패: " + str(e)[-200:])
    finally:
        shutil.rmtree(td, ignore_errors=True)


# ---------------- 악보 파일 저장 ----------------
SCORES = os.path.join(DATA, "scores")
EXT = ".ccmscore"


def safe_name(n):
    n = "".join("_" if c in '/\\:*?"<>|' or ord(c) < 32 else c for c in str(n)).strip().strip(".")
    return (n or "제목 없음")[:80]


def score_path(sid):
    sid = os.path.basename(str(sid))
    if not sid.endswith(EXT):
        raise EngineError("잘못된 파일 이름")
    return os.path.join(SCORES, sid)


def song_index(s):
    """악보 열기 창의 찾기용: 조·태그·빠르기·가사 첫 줄 (v45)"""
    first = ""
    try:
        for me in s.get("measures") or []:
            for n in me.get("notes") or []:
                ly = (n.get("ly") or [""])
                t = (ly[0] if ly else "") or ""
                if t.strip():
                    first += t.strip() + (" " if t.endswith(" ") else "")
            if len(first) > 40:
                break
    except Exception:
        pass
    tags = s.get("tags") if isinstance(s.get("tags"), list) else []
    return {"key": s.get("key", ""), "tags": [str(x) for x in tags][:20], "bpm": s.get("bpm") or 0, "first": first.strip()[:40]}


def scores_list():
    os.makedirs(SCORES, exist_ok=True)
    out = []
    for fp in glob.glob(os.path.join(SCORES, "*" + EXT)):
        try:
            with open(fp, encoding="utf-8") as f:
                d = json.load(f)
            s = d.get("song") or {}
            out.append({"id": os.path.basename(fp), "name": d.get("name") or os.path.basename(fp)[:-len(EXT)],
                        "mtime": int(os.path.getmtime(fp) * 1000), "measures": len(s.get("measures") or []),
                        "title": s.get("title", ""), "size": os.path.getsize(fp), **song_index(s)})
        except Exception:
            continue
    out.sort(key=lambda x: -x["mtime"])
    return out


VERDIR = os.path.join(SCORES, ".버전")


def ver_dir(sid=None, name=None):
    stem = os.path.basename(str(sid))[:-len(EXT)] if sid and str(sid).endswith(EXT) else safe_name(name or "")
    return os.path.join(VERDIR, safe_name(stem))


def prune(d, auto, keep):
    fs = sorted(f for f in os.listdir(d) if f.endswith(EXT) and (f.endswith("-auto" + EXT) == auto))
    for f in fs[:-keep] if len(fs) > keep else []:
        try:
            os.remove(os.path.join(d, f))
        except Exception:
            pass


def keep_version(fp, auto=False, data=None):
    """덮어쓰기 전 내용(또는 자동 백업)을 .버전/<이름>/ 에 보관"""
    try:
        d = ver_dir(os.path.basename(fp))
        os.makedirs(d, exist_ok=True)
        dst = os.path.join(d, time.strftime("%Y%m%d-%H%M%S") + "%03d" % (int(time.time() * 1000) % 1000) + ("-auto" if auto else "") + EXT)
        if data is not None:
            with open(dst + ".tmp", "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(dst + ".tmp", dst)
        elif os.path.exists(fp):
            shutil.copy2(fp, dst)
        prune(d, auto, 10 if auto else 20)
    except Exception:
        pass


def versions_list(sid, name):
    d = ver_dir(sid, name)
    out = []
    if os.path.isdir(d):
        for f in sorted(os.listdir(d), reverse=True):
            if not f.endswith(EXT):
                continue
            fp = os.path.join(d, f)
            try:
                with open(fp, encoding="utf-8") as fh:
                    dd = json.load(fh)
                out.append({"v": f, "mtime": int(os.path.getmtime(fp) * 1000), "auto": f.endswith("-auto" + EXT),
                            "measures": len((dd.get("song") or {}).get("measures") or []), "size": os.path.getsize(fp)})
            except Exception:
                continue
    out.sort(key=lambda x: -x["mtime"])
    return out


def version_get(sid, name, v):
    v = os.path.basename(str(v))
    if not v.endswith(EXT):
        raise EngineError("잘못된 버전")
    fp = os.path.join(ver_dir(sid, name), v)
    with open(fp, encoding="utf-8") as f:
        return json.load(f)


def score_save(req):
    os.makedirs(SCORES, exist_ok=True)
    name = safe_name(req.get("name") or "")
    sid = req.get("id") or (name + EXT)
    fp = score_path(sid)
    if req.get("rename_from") and req["rename_from"] != sid:
        old = score_path(req["rename_from"])
        if os.path.exists(fp):
            raise EngineError("같은 이름의 악보가 이미 있습니다")
        os.replace(old, fp)
        with open(fp, encoding="utf-8") as f:
            d = json.load(f)
        d["name"] = name
    else:
        d = req.get("data") or {}
        if not isinstance(d, dict) or not isinstance(d.get("song"), dict) or not isinstance(d["song"].get("measures"), list):
            raise EngineError("저장할 악보 내용이 올바르지 않습니다")
        d["name"] = name
        if os.path.exists(fp):
            keep_version(fp)  # 덮어쓰기 전 내용 보관
    tmp = fp + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(tmp, fp)
    return {"id": os.path.basename(fp), "name": name, "mtime": int(os.path.getmtime(fp) * 1000)}


def score_delete(sid):
    fp = score_path(sid)
    if os.path.exists(fp):
        trash = os.path.join(SCORES, ".휴지통")
        os.makedirs(trash, exist_ok=True)
        os.replace(fp, os.path.join(trash, time.strftime("%Y%m%d-%H%M%S-") + os.path.basename(fp)))
    return {"ok": True}


AI = {"agy-cli": run_agy_cli, "gemini": run_gemini, "openai": run_openai, "anthropic": run_anthropic, "lmstudio": run_lmstudio,
      "codex-cli": run_codex_cli, "gemini-cli": run_gemini_cli}


def engines_status():
    cfg = load_cfg()
    st = {}
    st["gemini"] = {"ok": bool(cfg.get("gemini_key")), "why": "API 키 없음 (엔진 설정)", "model": cfg.get("gemini_model")}
    st["openai"] = {"ok": bool(cfg.get("openai_key")), "why": "API 키 없음 (엔진 설정)", "model": cfg.get("openai_model")}
    st["anthropic"] = {"ok": bool(cfg.get("anthropic_key")), "why": "API 키 없음 (엔진 설정)", "model": cfg.get("anthropic_model")}
    ms = lmstudio_models(cfg)
    st["lmstudio"] = {"ok": bool(ms), "why": "LM Studio 서버가 꺼져 있음 (LM Studio에서 Developer → Start Server)" if ms is None else "불러온 모델 없음",
                      "model": cfg.get("lmstudio_model") or (ms[0] if ms else "")}
    st["codex-cli"] = {"ok": bool(shutil.which("codex")), "why": "codex 명령이 설치되어 있지 않음", "model": cfg.get("codex_model") or ""}
    gi = bool(shutil.which("gemini")); gl = gemini_logged_in()
    st["gemini-cli"] = {"ok": gi and gl, "why": "구글 개인 계정 로그인은 2026-06-18에 끝남 → Gemini 무료 API 키 또는 Antigravity" if gi else "설치되어 있지 않음",
                        "model": cfg.get("geminicli_model") or "", "installed": gi, "logged": gl}
    ai = bool(shutil.which("agy")); al = agy_logged_in() if ai else False
    st["agy-cli"] = {"ok": ai and al, "why": "로그인이 필요함 (인식률 도우미)" if ai else "설치되어 있지 않음 (인식률 도우미에서 무료 설치)",
                     "model": cfg.get("agy_model") or "", "installed": ai, "logged": al}
    st["homr"] = {"ok": bool(homr_exe()), "why": "설치되어 있지 않음 → 엔진 설정에서 ‘설치’"}
    st["audiveris"] = {"ok": bool(audiveris_exe(cfg)), "why": "설치되어 있지 않음 → 엔진 설정에서 ‘자동 설치’"}
    for v in st.values():
        if v["ok"]:
            v.pop("why", None)
    return {"engines": st, "version": 8, "app": app_info()}


# ---------------- 웹 서버 ----------------
class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "CCMScore/1"

    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

    def send_json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def guard(self):
        # 다른 웹사이트가 이 서버를 부르지 못하게: 사용자 정의 헤더 + 호스트 확인
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("localhost", "127.0.0.1") or self.headers.get("X-CCM") != "1":
            self.send_json({"error": "forbidden"}, 403)
            return False
        return True

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in STATIC:
            fp = os.path.join(ROOT, STATIC[path])
            if not os.path.exists(fp):
                self.send_error(404)
                return
            data = open(fp, "rb").read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8" if fp.endswith(".html") else "application/javascript")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(data)
            return
        if path == "/api/tool/agystatus":
            if self.guard():
                self.send_json(agy_pty_status())
            return
        if path == "/api/tool/status":
            if self.guard():
                from urllib.parse import urlparse, parse_qs
                name = (parse_qs(urlparse(self.path).query).get("n") or [""])[0]
                self.send_json(dict(TOOL_ST.get(name) or {"state": "idle"}, gemini={"installed": bool(shutil.which("gemini")), "logged": gemini_logged_in()},
                                    agy={"installed": bool(shutil.which("agy")), "logged": agy_logged_in() if shutil.which("agy") else False}))
            return
        if path == "/api/engines":
            if self.guard():
                self.send_json(engines_status())
            return
        if path == "/api/scores":
            if self.guard():
                self.send_json(scores_list())
            return
        if path.startswith("/api/scores/"):
            if self.guard():
                try:
                    from urllib.parse import unquote
                    with open(score_path(unquote(path[len("/api/scores/"):])), encoding="utf-8") as f:
                        self.send_json(json.load(f))
                except Exception:
                    self.send_json({"error": "악보를 찾을 수 없습니다"}, 404)
            return
        if path == "/api/sf":
            # 악기 소리(사운드폰트) — 처음 한 번만 받아 맥에 저장해 두고 그 뒤로는 인터넷 없이 씀
            if self.guard():
                from urllib.parse import urlparse, parse_qs
                q = parse_qs(urlparse(self.path).query)
                name = (q.get("n") or [""])[0]
                font = (q.get("f") or ["FluidR3_GM"])[0]
                import re as _re
                if not _re.fullmatch(r"[a-z0-9_]{2,60}", name) or font not in ("FluidR3_GM", "MusyngKite"):
                    self.send_json({"error": "bad name"}, 400)
                    return
                d = os.path.join(DATA, "soundfonts", font)
                os.makedirs(d, exist_ok=True)
                fp = os.path.join(d, name + "-mp3.js")
                if not os.path.exists(fp) or os.path.getsize(fp) < 1000:
                    url = "https://gleitz.github.io/midi-js-soundfonts/%s/%s-mp3.js" % (font, name)
                    tmp = fp + ".part"
                    try:
                        r = subprocess.run(["curl", "-sSfL", "-m", "120", "-o", tmp, url], capture_output=True, text=True, timeout=150)
                        if r.returncode != 0 or not os.path.exists(tmp) or os.path.getsize(tmp) < 1000:
                            raise RuntimeError((r.stderr or "download failed").strip()[:200])
                        os.replace(tmp, fp)
                    except Exception as e:
                        try:
                            os.remove(tmp)
                        except Exception:
                            pass
                        self.send_json({"error": "악기 소리를 받지 못했습니다: %s" % e}, 502)
                        return
                data = open(fp, "rb").read()
                self.send_response(200)
                self.send_header("Content-Type", "application/javascript")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "max-age=86400")
                self.end_headers()
                self.wfile.write(data)
            return
        if path in ("/api/versions", "/api/versions/get"):
            if self.guard():
                from urllib.parse import urlparse, parse_qs
                q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
                try:
                    if path == "/api/versions":
                        self.send_json(versions_list(q.get("id"), q.get("name")))
                    else:
                        self.send_json(version_get(q.get("id"), q.get("name"), q.get("v", "")))
                except Exception as e:
                    self.send_json({"error": "이전 버전을 찾을 수 없습니다"}, 404)
            return
        if path == "/api/install/status":
            if self.guard():
                self.send_json(INSTALL)
            return
        if path == "/api/config":
            if self.guard():
                cfg = load_cfg()
                out = {k: v for k, v in cfg.items() if not k.endswith("_key")}
                for k in ("gemini_key", "openai_key", "anthropic_key"):
                    out[k + "_set"] = bool(cfg.get(k))
                self.send_json(out)
            return
        self.send_error(404)

    def do_POST(self):
        if not self.guard():
            return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            req = json.loads(self.rfile.read(n).decode() or "{}")
        except Exception:
            self.send_json({"error": "잘못된 요청"}, 400)
            return
        path = self.path.split("?")[0]
        try:
            if path == "/api/config":
                cfg = load_cfg()
                for k, v in req.items():
                    if k in DEFAULTS or k in ("gemini_key", "openai_key", "anthropic_key"):
                        cfg[k] = str(v).strip()
                save_cfg(cfg)
                self.send_json({"ok": True})
            elif path == "/api/ai":
                eng = req.get("engine")
                if eng not in AI:
                    raise EngineError("알 수 없는 엔진: " + str(eng))
                imgs = req.get("images") or []
                t0 = time.time()
                txt = AI[eng](load_cfg(), str(req.get("prompt") or ""), imgs, req.get("tier"))
                self.log_message("%s %d장 %.1f초", eng, len(imgs), time.time() - t0)
                self.send_json({"text": txt})
            elif path == "/api/scores":
                self.send_json(score_save(req))
            elif path == "/api/scores/autosave":
                d = req.get("data") or {}
                if isinstance(d, dict) and isinstance(d.get("song"), dict):
                    sid = req.get("id") or (safe_name(req.get("name") or "") + EXT)
                    keep_version(score_path(sid), auto=True, data=d)
                self.send_json({"ok": True})
            elif path == "/api/scores/delete":
                self.send_json(score_delete(req.get("id")))
            elif path == "/api/update/check":
                self.send_json(update_check())
            elif path == "/api/update/apply":
                if req.get("data"):
                    raw = base64.b64decode(req["data"])
                    sha = None
                elif req.get("url"):
                    r = subprocess.run(["curl", "-sSfL", "-m", "180", req["url"]], capture_output=True, timeout=200)
                    if r.returncode != 0:
                        raise EngineError("패치를 받지 못했습니다: " + (r.stderr.decode(errors="ignore") or "")[:200])
                    raw, sha = r.stdout, req.get("sha256")
                else:
                    raise EngineError("패치가 없습니다")
                self.send_json(install_patch(raw, sha))
            elif path == "/api/update/rollback":
                self.send_json(update_rollback())
            elif path == "/api/update/feed":
                cfg = load_cfg()
                cfg["update_url"] = str(req.get("url") or "").strip()
                save_cfg(cfg)
                self.send_json({"ok": True})
            elif path == "/api/restart":
                self.send_json({"ok": True})
                threading.Timer(0.3, lambda: os._exit(3)).start()
            elif path == "/api/install/audiveris":
                if INSTALL["state"] != "run":
                    _inst("run", "시작하는 중…", 0)
                    threading.Thread(target=install_audiveris, daemon=True).start()
                self.send_json(INSTALL)
            elif path == "/api/tool/install":
                name = req.get("name")
                if name not in TOOL_ST:
                    raise EngineError("알 수 없는 도구")
                if TOOL_ST[name]["state"] != "run":
                    _tst(name, "run", "시작하는 중…", 0)
                    threading.Thread(target={"geminicli": install_geminicli, "homr": install_homr, "agy": install_agy}[name], daemon=True).start()
                self.send_json(TOOL_ST[name])
            elif path == "/api/tool/geminilogin":
                self.send_json(gemini_login())
            elif path == "/api/tool/agylogin":
                self.send_json(agy_login())
            elif path == "/api/tool/agystart":
                self.send_json(agy_pty_start())
            elif path == "/api/tool/agystop":
                agy_pty_stop()
                self.send_json({"ok": True})
            elif path == "/api/tool/agycode":
                self.send_json(agy_code(str(req.get("code") or "")))
            elif path == "/api/tool/testgemini":
                self.send_json(test_gemini_key(str(req.get("key") or "")))
            elif path == "/api/homr":
                self.send_json({"xml": run_homr(req.get("image") or "")})
            elif path == "/api/audiveris":
                self.send_json({"mxl": run_audiveris(load_cfg(), req.get("image") or "")})
            else:
                self.send_json({"error": "없는 주소"}, 404)
        except EngineError as e:
            self.send_json({"error": str(e)}, 502)
        except subprocess.TimeoutExpired:
            self.send_json({"error": "시간 초과"}, 504)
        except Exception as e:
            self.send_json({"error": "오류: " + str(e)[:300]}, 500)


# ---------------- 업데이트 (패치) ----------------
# 패치 파일(.ccmpatch) = zip: VERSION.json(build·version) + index.html + ccm_score_server.py (+ pptxgen.bundle.js)
# 받은 패치는 DATA/app/<build>/ 에 풀고 DATA/app/current 에 build 번호를 적음 → 앱 껍데기(launcher)가 다시 켤 때 그쪽을 씀.
# 앱 안의 원래 파일은 절대 건드리지 않음 → ‘처음 설치 판으로 되돌리기’ = current 지우기.
APPS = os.path.join(DATA, "app")
NEED = ("VERSION.json", "index.html", "ccm_score_server.py")


def feed_url():
    return (load_cfg().get("update_url") or app_info().get("feed") or "").strip()


def update_check():
    url = feed_url()
    if not url:
        return {"ok": False, "error": "업데이트 주소가 정해지지 않았습니다 — 패치 파일로 업데이트하세요", "app": app_info()}
    r = subprocess.run(["curl", "-sSfL", "-m", "20", url], capture_output=True, timeout=30)
    if r.returncode != 0:
        return {"ok": False, "error": "업데이트 정보를 받지 못했습니다: " + (r.stderr.decode(errors="ignore") or "")[:200], "app": app_info()}
    m = json.loads(r.stdout.decode("utf-8"))
    cur = app_info()["build"]
    if m.get("url") and not m["url"].startswith("http"):
        m["url"] = url.rsplit("/", 1)[0] + "/" + m["url"]          # update.json 옆의 파일
    return {"ok": True, "latest": m, "newer": int(m.get("build", 0)) > int(cur), "app": app_info()}


def install_patch(raw, sha=None):
    import hashlib, io, zipfile
    if sha and hashlib.sha256(raw).hexdigest() != sha.lower():
        raise EngineError("패치 파일이 손상되었습니다 (확인값 불일치)")
    try:
        z = zipfile.ZipFile(io.BytesIO(raw))
    except Exception:
        raise EngineError("패치 파일(.ccmpatch)이 아닙니다")
    names = z.namelist()
    for n in NEED:
        if n not in names:
            raise EngineError("패치 파일에 %s 가 없습니다" % n)
    for n in names:
        if n.startswith("/") or ".." in n.split("/"):
            raise EngineError("패치 파일에 잘못된 경로가 있습니다")
    ver = json.loads(z.read("VERSION.json").decode("utf-8"))
    build = int(ver.get("build") or 0)
    if build <= 0:
        raise EngineError("패치 파일의 판 번호가 없습니다")
    os.makedirs(APPS, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix=".patch-", dir=APPS)
    z.extractall(tmp)
    # 빠진 보조 파일은 지금 쓰는 판에서 가져옴
    for extra in ("pptxgen.bundle.js",):
        if not os.path.exists(os.path.join(tmp, extra)) and os.path.exists(os.path.join(ROOT, extra)):
            shutil.copy2(os.path.join(ROOT, extra), os.path.join(tmp, extra))
    # 새 서버 파일이 파이썬으로 읽히는지 미리 확인
    r = subprocess.run([sys.executable, "-c", "import ast,sys;ast.parse(open(sys.argv[1],encoding='utf-8').read())", os.path.join(tmp, "ccm_score_server.py")], capture_output=True, timeout=30)
    if r.returncode != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise EngineError("패치의 서버 파일에 오류가 있습니다")
    dst = os.path.join(APPS, str(build))
    if os.path.exists(dst):
        shutil.rmtree(dst, ignore_errors=True)
    os.replace(tmp, dst)
    with open(os.path.join(APPS, "current"), "w") as f:
        f.write(str(build))
    try:
        os.remove(os.path.join(APPS, "bad"))
    except Exception:
        pass
    # 오래된 패치는 최근 3개만 남김
    olds = sorted([int(x) for x in os.listdir(APPS) if x.isdigit()], reverse=True)
    for b in olds[3:]:
        if b != build:
            shutil.rmtree(os.path.join(APPS, str(b)), ignore_errors=True)
    return {"ok": True, "build": build, "version": ver.get("version", "")}


def update_rollback():
    try:
        os.remove(os.path.join(APPS, "current"))
    except FileNotFoundError:
        pass
    return {"ok": True}


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    url = f"http://localhost:{PORT}/"
    try:
        srv = Server(("127.0.0.1", PORT), Handler)
    except OSError:
        print("이미 실행 중입니다. 브라우저에서 엽니다:", url)
        webbrowser.open(url)
        return
    print("찬양 악보 편집기 (맥 앱) 실행 중:", url)
    print("이 창을 닫으면 앱이 종료됩니다.")
    st = engines_status()["engines"]
    print("사용 가능한 엔진:", ", ".join(k for k, v in st.items() if v["ok"]) or "(없음 — 편집기의 ‘엔진 설정’에서 키 입력)")
    if os.environ.get("CCM_NO_BROWSER") != "1":
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
