#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""맥 앱 켜고 끄기 — 서버(ccm_score_server.py)를 그대로 불러와서 ‘살아 있음/닫음/끝내기’만 덧붙여 실행.
편집기 창이 열려 있는 동안만 켜져 있고, 창이 모두 닫히면 몇 초 뒤 스스로 깔끔하게 끝남(→ 앱도 같이 끝남).
  POST /api/ping {id}   창이 5초마다 보냄
  POST /api/bye?id=     창을 닫을 때 (sendBeacon — 머리말을 못 붙여 호스트만 확인)
  POST /api/quit        ‘끝내기’ 단추
"""
import os, sys, threading, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ccm_score_server as S
from urllib.parse import urlparse, parse_qs

LIFE = {"clients": {}, "seen": False, "t0": time.time(), "empty_since": None}
LOCK = threading.Lock()


def ping(cid):
    with LOCK:
        LIFE["clients"][cid] = time.time(); LIFE["seen"] = True; LIFE["empty_since"] = None


def bye(cid):
    with LOCK:
        LIFE["clients"].pop(cid, None)
        if not LIFE["clients"]:
            LIFE["empty_since"] = time.time()


def busy():
    try:
        if S.INSTALL.get("state") == "run":
            return True
        if any((v or {}).get("state") == "run" for v in S.TOOL_ST.values()):
            return True
    except Exception:
        pass
    return False


def watch():
    while True:
        time.sleep(2)
        now = time.time()
        with LOCK:
            for k, t in list(LIFE["clients"].items()):
                if now - t > 180:            # 숨겨진 창은 크롬이 1분에 한 번만 보낼 수 있어 넉넉히
                    LIFE["clients"].pop(k, None)
            empty = not LIFE["clients"]
            if empty and LIFE["empty_since"] is None:
                LIFE["empty_since"] = now
            since, seen = LIFE["empty_since"], LIFE["seen"]
        if busy():
            continue
        if seen and empty and since and now - since > 6:
            print("편집기 창이 모두 닫혀 끝냅니다."); sys.stdout.flush(); os._exit(0)
        if not seen and now - LIFE["t0"] > 180:
            print("편집기 창이 열리지 않아 끝냅니다."); sys.stdout.flush(); os._exit(0)


_post = S.Handler.do_POST


def do_POST(self):
    path = self.path.split("?")[0]
    host = (self.headers.get("Host") or "").split(":")[0]
    if path == "/api/bye":
        if host in ("localhost", "127.0.0.1"):
            bye((parse_qs(urlparse(self.path).query).get("id") or [""])[0])
        self.send_response(204); self.end_headers()
        return
    if path in ("/api/ping", "/api/quit"):
        if host not in ("localhost", "127.0.0.1") or self.headers.get("X-CCM") != "1":
            self.send_json({"error": "forbidden"}, 403); return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            req = S.json.loads(self.rfile.read(n).decode() or "{}")
        except Exception:
            req = {}
        if path == "/api/ping":
            ping(str(req.get("id") or "x"))
            self.send_json({"ok": True, "auto_exit": True})
        else:
            self.send_json({"ok": True})
            threading.Timer(0.3, lambda: os._exit(0)).start()
        return
    return _post(self)


S.Handler.do_POST = do_POST

if __name__ == "__main__":
    threading.Thread(target=watch, daemon=True).start()
    S.main()
